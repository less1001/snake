import SnakeGame from '@/components/SnakeGame'

export default function Home() {
  return <SnakeGame />
}