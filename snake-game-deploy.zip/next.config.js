/** @type {import('next').NextConfig} */
const nextConfig = {
  // Next.js 14+ 默认启用 App Router，不需要 experimental.appDir
}

module.exports = nextConfig